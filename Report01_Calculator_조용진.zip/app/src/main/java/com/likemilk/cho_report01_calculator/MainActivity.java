package com.likemilk.cho_report01_calculator;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



// 토크나이저로 \b 을 나누고 그다음에 나눈 토크나이저를 스트링변수에 저장후
// 연산자를 포함한 문자열을 따로 배분한다음에 순위를 매겨서 연산순서 지정한다.
// HashMap 으로 연산자를 저장하여 연산자나 bracket 소괄호가 포함되어있는 변수를
// 지정하여 나눈다.


public class MainActivity extends ActionBarActivity {
    Button btn_1,btn_2,btn_3,btn_4,
            btn_5,btn_6,btn_7,btn_8,
            btn_9,btn_0,btn_comma,btn_divide,
            btn_multiple,btn_substract,btn_add,btn_namuzi,
            btn_goCalc,btn_bracket,btn_cancel,btn_backspace;

    int whatTimeNumClicks = 0;
    int whatTimeDecimalPointClick = 0;
    TextView input,output;
    boolean comma = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = (TextView) findViewById(R.id.textView);
        output = (TextView)findViewById(R.id.textView2);
        input.setText("");
        output.setText("");
        setBtn();
    }
    public void setBtn(){
        btn_0=(Button)findViewById(R.id.btn_0);
        btn_1=(Button)findViewById(R.id.btn_1);
        btn_2=(Button)findViewById(R.id.btn_2);
        btn_3=(Button)findViewById(R.id.btn_3);
        btn_4=(Button)findViewById(R.id.btn_4);
        btn_5=(Button)findViewById(R.id.btn_5);
        btn_6=(Button)findViewById(R.id.btn_6);
        btn_7=(Button)findViewById(R.id.btn_7);
        btn_8=(Button)findViewById(R.id.btn_8);
        btn_9=(Button)findViewById(R.id.btn_9);
        btn_comma=(Button)findViewById(R.id.btn_com);
        btn_add=(Button)findViewById(R.id.btn_add);
        btn_substract=(Button)findViewById(R.id.btn_subs);
        btn_multiple=(Button)findViewById(R.id.btn_multi);
        btn_divide=(Button)findViewById(R.id.btn_divide);
        btn_goCalc=(Button)findViewById(R.id.btn_calc);
        btn_cancel=(Button)findViewById(R.id.btn_cancel);
        btn_namuzi=(Button)findViewById(R.id.btn_namuzi);
        btn_bracket=(Button)findViewById(R.id.btn_bracket);
        btn_backspace=(Button)findViewById(R.id.btn_backspace);

        btn_0.setOnClickListener(new NumberButton());
        btn_1.setOnClickListener(new NumberButton());
        btn_2.setOnClickListener(new NumberButton());
        btn_3.setOnClickListener(new NumberButton());
        btn_4.setOnClickListener(new NumberButton());
        btn_5.setOnClickListener(new NumberButton());
        btn_6.setOnClickListener(new NumberButton());
        btn_7.setOnClickListener(new NumberButton());
        btn_8.setOnClickListener(new NumberButton());
        btn_9.setOnClickListener(new NumberButton());
        btn_comma.setOnClickListener(new NumberButton());

        btn_backspace.setOnClickListener(new RemoveButton());
        btn_cancel.setOnClickListener(new RemoveButton());


        btn_add.setOnClickListener(new OperatorButton());
        btn_substract.setOnClickListener(new OperatorButton());
        btn_multiple.setOnClickListener(new OperatorButton());
        btn_divide.setOnClickListener(new OperatorButton());
        btn_namuzi.setOnClickListener(new OperatorButton());
        btn_bracket.setOnClickListener(new OperatorButton());


        btn_goCalc.setOnClickListener(new NumberButton());
    }


    class NumberButton implements View.OnClickListener{
        public void onClick(View view){
            Button b = (Button) view;
            String str = input.getText().toString();

            if(whatTimeNumClicks<16) {
                if(!comma){
                    if (btn_0 == b) {
                        whatTimeNumClicks++;
                        input.append("0");

                    }else if (btn_1 == b) {
                        ++whatTimeNumClicks;
                        input.append("1");

                    }else if (btn_2 == b) {
                        ++whatTimeNumClicks;
                        input.append("2");

                    }else if (btn_3 == b) {
                        ++whatTimeNumClicks;
                        input.append("3");

                    }else if (btn_4 == b) {
                        ++whatTimeNumClicks;
                        input.append("4");

                    }else if (btn_5 == b) {
                        ++whatTimeNumClicks;
                        input.append("5");

                    }else if (btn_6 == b) {
                        ++whatTimeNumClicks;
                        input.append("6");

                    }else if (btn_7 == b) {
                        ++whatTimeNumClicks;
                        input.append("7");

                    }else if (btn_8 == b) {
                        ++whatTimeNumClicks;
                        input.append("8");

                    }else if (btn_9 == b) {
                        ++whatTimeNumClicks;
                        input.append("9");
                    }else if (btn_comma == b) {
                        if (!comma) {
                            input.append(".");
                            comma = true;
                        } else {
                            Toast.makeText(getBaseContext(), "소수점 연산은 단 한번밖에 안됩니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }else if(comma){
                    if(whatTimeDecimalPointClick<5){
                        if (btn_0 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("0");

                        }else if (btn_1 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("1");

                        }else if (btn_2 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("2");

                        }else if (btn_3 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("3");

                        }else if (btn_4 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("4");

                        }else if (btn_5 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("5");

                        }else if (btn_6 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("6");

                        }else if (btn_7 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("7");

                        }else if (btn_8 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("8");

                        }else if (btn_9 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("9");
                        }
                    }
                    else{
                        Toast.makeText(getBaseContext(),"소수점 최대 5자리까지 지원합니다.",Toast.LENGTH_SHORT ).show();
                    }
                }
            }else if (btn_comma == b) {
                if (!comma) {
                    input.append(".");
                    comma = true;
                } else {
                    Toast.makeText(getBaseContext(), "소수점 연산은 단 한번밖에 안됩니다.", Toast.LENGTH_SHORT).show();
                }
            }else if(whatTimeNumClicks==16){
                if(comma){
                    if(whatTimeDecimalPointClick<5) {
                        if (btn_0 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("0");

                        } else if (btn_1 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("1");

                        } else if (btn_2 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("2");

                        } else if (btn_3 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("3");

                        } else if (btn_4 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("4");

                        } else if (btn_5 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("5");

                        } else if (btn_6 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("6");

                        } else if (btn_7 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("7");

                        } else if (btn_8 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("8");

                        } else if (btn_9 == b) {
                            ++whatTimeDecimalPointClick;
                            input.append("9");
                        }
                    }
                }else{
                    Toast.makeText(getBaseContext(),"소수점 최대 5자리까지 지원합니다.",Toast.LENGTH_SHORT ).show();
                }
            }
            else{
                Toast.makeText(getBaseContext(),"최대 16자리까지 지원합니다.",Toast.LENGTH_SHORT ).show();
            }
        }
    }
    class RemoveButton implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Button b = (Button) v;
            String str = input.getText().toString();
            if(btn_cancel==b){
                whatTimeNumClicks=0;
                whatTimeDecimalPointClick=0;
                input.setText("");
            }else {
                if(comma) {
                    --whatTimeDecimalPointClick;
                    str = str.substring(0, str.length() - 1);
                    input.setText(str);
                    if (whatTimeDecimalPointClick == 0) {
                        str = str.substring(0, str.length() - 1);
                        input.setText(str);
                        comma=false;
                    }
                }else{
                    if (str != null && str.length() != 0) {
                        str = str.substring(0, str.length() - 1);
                        --whatTimeNumClicks;
                        input.setText(str);
                    }else if(str == null || str.length() == 0){

                    }
                    else {
                        Toast.makeText(getBaseContext(),"에러가 발생하였습니다. AC 버튼으로 초기화 해주세요.",Toast.LENGTH_SHORT ).show();
                    }
                }
            }
        }
    }
    class OperatorButton implements View.OnClickListener{

        @Override
        public void onClick(View v) {

        }
    }
}
