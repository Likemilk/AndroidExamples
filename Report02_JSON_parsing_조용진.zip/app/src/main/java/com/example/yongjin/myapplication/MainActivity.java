package com.example.yongjin.myapplication;

import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.*;
import java.text.*;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends ActionBarActivity {

    TextView text1;
    String JSONDocument;
    JSONHandler handler;
    long sunrise,sunset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = (TextView)findViewById(R.id.textView);

        handler = new JSONHandler();
    }

    public void json_parse(View view){
        JSONThread t = new JSONThread();
        t.start();
    }
    class JSONThread extends Thread{
        @Override
        public void run() {
            try{
                URL url = new URL("http://api.openweathermap.org/data/2.5/weather?q=seoul&mode=json&units=metric");
                URLConnection conn = url.openConnection();
                InputStream is = conn.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String str;
                StringBuffer buf = new StringBuffer();


                while((str=br.readLine())!=null){
                    buf.append(str);
                }

                String rec_data=buf.toString();

                JSONDocument = rec_data;
                JSONObject json_object = new JSONObject(rec_data);
                Log.d("테스트",rec_data);

                for(int i=0;i<=json_object.length();i++){
                    JSONObject obj = json_object.getJSONObject("sys");
                    for(int j=0; j<=obj.length();j++){
                        sunrise = obj.getLong("sunrise");
                        sunset = obj.getLong("sunset");
                    }
                }

                handler.sendEmptyMessage(0);
            }catch(Exception e){
                e.printStackTrace();
            }

        }
    }
    class JSONHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(msg.what==0){

                text1.setText("Sunrise : \n"+getDate(sunrise)+"\n");
                text1.append("Sunset : \n"+getDate(sunset)+"\n");
            }
        }
        public String getDate(long millitime){
            long d = millitime*1000;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM년dd일 || HH시mm분");
            Date resultdate = new Date(d);
            Log.d("dn우융유",sdf.format(resultdate));
            return sdf.format(resultdate);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
